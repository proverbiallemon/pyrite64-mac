/**
* @copyright 2024 - Max Bebök
* @license MIT
*/
#pragma once

namespace P64::AudioManager {
  void init();
  void update();
  void destroy();
}
