/**
* @copyright 2024 - Max Bebök
* @license MIT
*/

namespace P64::VI
{
  float calcRefreshRate();
}
